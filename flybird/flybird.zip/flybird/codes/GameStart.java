public class GameStart {
	public static void main(String[] args){
		GameFrame game=new GameFrame();
		game.setVisible(true);
	}
}
